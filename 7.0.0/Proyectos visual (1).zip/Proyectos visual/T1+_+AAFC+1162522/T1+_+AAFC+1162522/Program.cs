﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo programa ");
        Console.WriteLine("Ingrese su nombre ");
        string Nombre = Console.ReadLine();
        Console.WriteLine("Ingrese su edad ");
        string Edad = Console.ReadLine();
        Console.WriteLine("Ingrese su carrera ");
        string Carrera = Console.ReadLine();
        Console.WriteLine("Ingrese su carné ");
        string Carné = Console.ReadLine();


        /* COMENTARIOS */
        Console.WriteLine("Mi segundo programa ");
        Console.WriteLine("Soy " + Nombre + ",Tengo  " + Edad  + " años y estudio la carrera de " + Carrera  + ".Mi numero de carne es; " + Carné  );

        Console.ReadKey();

    }
}
