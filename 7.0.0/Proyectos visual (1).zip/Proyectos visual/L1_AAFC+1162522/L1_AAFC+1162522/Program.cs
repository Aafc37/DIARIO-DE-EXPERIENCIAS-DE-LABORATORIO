﻿class Program
{
    static void Main(string[] args)
    {

        Console.WriteLine("Ingrese su nombre: ");
        string Nombre = Console.ReadLine();



        Console.WriteLine("Hola Mundo");
        Console.WriteLine("Soy" + Nombre);

        /* COMENTARIOS */

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("Soy" + Nombre);

        Console.ReadKey();

}
}

